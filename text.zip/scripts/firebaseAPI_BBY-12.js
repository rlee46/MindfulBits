//----------------------------------------
//  Your web app's Firebase configuration
//----------------------------------------
var firebaseConfig = {
  apiKey: "AIzaSyDsDsHs07VFMKaauVkKZKIzTG3c1hbOhf0",
  authDomain: "mindfulbits-ccc74.firebaseapp.com",
  projectId: "mindfulbits-ccc74",
  storageBucket: "mindfulbits-ccc74.appspot.com",
  messagingSenderId: "688294722479",
  appId: "1:688294722479:web:6fba53db47222cc6660d5a",
  measurementId: "G-5J0VH7YF6V"
};

//--------------------------------------------
// initialize the Firebase app
// initialize Firestore database if using it
//--------------------------------------------
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();